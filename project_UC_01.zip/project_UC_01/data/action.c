Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=84", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("dbl=336ed9b0b43dd2c58aa97539af468a72; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("fco2r34=336ed9b0b43dd2c58aa97539af468a72; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("_gcl_au=1.1.85823550.1597389182; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("supportOnlineTalkID=uwRLLkcDAvtTDOT7tb21AoKHfmzblh4D; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("userId=493309961; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("newTesterState=welcome; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("intercom-id-fkbc3no8=8b9b67e7-80d6-47fb-b707-eb3407cbad65; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("intercom-session-fkbc3no8=; DOMAIN=loadtest.uxcrowd.ru");

	web_add_cookie("semantiqo_a=336ed9b0b43dd2c58aa97539af468a72; DOMAIN=sonar.semantiqo.com");

	web_add_cookie("Semantiqo_a=21fa35e3b2f54f659e88d682d1cf2797; DOMAIN=sonar.semantiqo.com");

	web_add_cookie("w_b=336ed9b0b43dd2c58aa97539af468a72; DOMAIN=sonar.semantiqo.com");

	web_add_cookie("c82=336ed9b0b43dd2c58aa97539af468a72; DOMAIN=sonar.semantiqo.com");

	web_url("loadtest.uxcrowd.ru", 
		"URL=https://loadtest.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/landing/webflow.css", ENDITEM, 
		"Url=/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/assets/gulp/env.js", ENDITEM, 
		"Url=/assets/css/landing/uxcrowd.webflow.css", ENDITEM, 
		"Url=/library/jquery.form.js", ENDITEM, 
		"Url=/library/jquery.js", ENDITEM, 
		"Url=/library/moment.min.js", ENDITEM, 
		"Url=/library/jquery.uploadfile.min.js", ENDITEM, 
		"Url=/library/FileSaver.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.js", ENDITEM, 
		"Url=/assets/js/main_js/init.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.rule.js", ENDITEM, 
		"Url=/assets/js/main_js/mediaelement-and-player.js", ENDITEM, 
		"Url=/assets/js/app_js/auth.interceptor.js", ENDITEM, 
		"Url=/assets/gulp/app_js.js", ENDITEM, 
		"Url=/assets/gulp/admin_js.js", ENDITEM, 
		"Url=/assets/gulp/customer_js.js", ENDITEM, 
		"Url=/assets/gulp/sup_js.js", ENDITEM, 
		"Url=/assets/gulp/blog_js.js", ENDITEM, 
		"Url=/assets/gulp/home_js.js", ENDITEM, 
		"Url=/assets/gulp/moderator_js.js", ENDITEM, 
		"Url=/assets/gulp/new_tester_js.js", ENDITEM, 
		"Url=/assets/gulp/tester_js.js", ENDITEM, 
		"Url=/library/require.js", ENDITEM, 
		"Url=/assets/js/main_js/path_controller.js", ENDITEM, 
		"Url=/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", ENDITEM, 
		"Url=/assets/js/main_js/main_route.js", ENDITEM, 
		"Url=https://ulclick.ru/b-count.js", ENDITEM, 
		"Url=https://sonar.semantiqo.com/c83ul/checking.js", ENDITEM, 
		"Url=https://use.typekit.net/hym5rnq.js", ENDITEM, 
		"Url=/assets/lang/ru.json", ENDITEM, 
		"Url=/controller/controller_home/newMain.controller.js?bust=1597875163134", ENDITEM, 
		"Url=/controller/controller_home/login.controller.js?bust=1597875163134", ENDITEM, 
		"Url=/app.js?bust=1597875163134", ENDITEM, 
		LAST);

	web_add_cookie("CONSENT=YES+RU.ru+20170709-09-0; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfHur5A6GUSm_RrnVb09dKBxnaVejC2EhrzYXqonbqxdrtuPlo_paMhHq0LvCtNKZP7W; DOMAIN=accounts.google.com");

	web_add_cookie("ANID=AHWqTUktvFaZx-0AlR5eumb44Ex3z5y9aEpuAMBvKJUdu1BbWk3-wtnBFHc6RgAV; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIuZAB; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6dxVgo9DKHFRYKKHBlievQMItdv7oIabBULA3qPLYyrPxCtK4LtlPn-a0uPL8Vzuh41c2e_BXTaIXQFWo06fma5IebXSF-ZNYSCPmnC5bAl8oFOIU4Y4T53xWjQghWL9YohuH36QEnoGDE9BVWu7PO7fwZdg; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2020-08-19-15; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:pdX9I6XJbcN7wkAJ_RSvrjwZVp9fvR0cfSmJuIb0HPPr4cXgASVEs3cangc2ZR7g-awJPYUZyYtyfjnVvLa-WWg942TH-g:ijA2ZNzOn1XD0GMG; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:pdX9I6XJbcN7wkAJ_RSvrjwZVp9fvR0cfSmJuIb0HPPr4cXgASVEs3cangc2ZR7g-awJPYUZyYtyfjnVvLa-WWg942TH-g:ijA2ZNzOn1XD0GMG; DOMAIN=accounts.google.com");

	web_add_cookie("NID=204=XALcdQKBUI843fgG-U7g2J4OwKqJgdQo_zhfiNderdzZvOYAfkHBVVug9uMiZndwlcD2Od25BjLI96yUrqRHBmdF0KA74BGNLYsbvjCfp4IIG8xlsHVNEe2i-1iJg5JnYotS-gnDr2NIfJfsZprHGqDdkha9Yqc4pUk5SFPGWMOZmzB0eyy2VCpTjexmQpEClIZL; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_url("i", 
		"URL=https://sonar.semantiqo.com/i/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=b.js", ENDITEM, 
		LAST);

	web_url("headerGreenWhite.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_landing_new/headerGreenWhite.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_landing_new/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footer.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_landing_new/footer.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	web_url("loadtest.uxcrowd.ru_2", 
		"URL=https://loadtest.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/landing/youtube-play.svg", "Referer=https://loadtest.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/assets/images/uxcrowd-logo-new.svg", ENDITEM, 
		"Url=/assets/images/burger-white-mobile.svg", ENDITEM, 
		"Url=https://p.typekit.net/p.gif?s=1&k=hym5rnq&ht=tk&h=loadtest.uxcrowd.ru&f=10879.10881.10884.10885.15586&a=9108420&js=1.19.4&app=typekit&e=js&_=1597875166912", ENDITEM, 
		"Url=/assets/images/uxcrowd-logo-white-mobile.svg", ENDITEM, 
		"Url=/assets/images/nl-home-girl.svg", ENDITEM, 
		"Url=/assets/images/avatar-white-mobile.svg", ENDITEM, 
		"Url=/assets/images/nl-home-top-blot.svg", ENDITEM, 
		"Url=/assets/images/youtube-colored.svg", ENDITEM, 
		"Url=/assets/images/facebook-colored.svg", ENDITEM, 
		"Url=/assets/images/google-play-btn.png", ENDITEM, 
		"Url=/assets/images/nl-home-work-arrow.svg", ENDITEM, 
		"Url=/assets/images/nl-home-work-blot-rect.svg", ENDITEM, 
		"Url=/assets/images/nl-home-work-blot-circle.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-1.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-2.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-3.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-rabota_ru.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-gazprombank.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-5.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-2.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-3.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-4.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-1.svg", ENDITEM, 
		"Url=/assets/images/egor_golubev.png", ENDITEM, 
		"Url=/assets/images/svetlana_gorshkova.jpg", ENDITEM, 
		"Url=/assets/images/ildar_mullahmetov.png", ENDITEM, 
		"Url=/assets/images/nl-home-clients-blot-mobile.svg", ENDITEM, 
		"Url=/assets/images/nl-home-center-blot.png", ENDITEM, 
		"Url=/assets//images/question.png", ENDITEM, 
		"Url=/assets/images/Rectangle%205.2.png", ENDITEM, 
		"Url=/assets/images/nl-home-blot-bottom-mobile.svg", ENDITEM, 
		"Url=/assets/images/ux-logo-new-white.svg", ENDITEM, 
		"Url=/assets/images/youtube.svg", ENDITEM, 
		"Url=/assets/images/facebook.svg", ENDITEM, 
		"Url=/controller/controller_home/home.controller.js?bust=1597875163134", ENDITEM, 
		"Url=/controller/controller_home/success.controller.js?bust=1597875163134", ENDITEM, 
		LAST);

	web_add_cookie("aep_usuc_f=site=rus&c_tp=USD&region=US&b_locale=ru_RU; DOMAIN=best.aliexpress.ru");

	web_add_cookie("xman_f=+K8OQADpEiyAIWAAsSxDPdXWE6Y3wlyDbg7L6Ru/Sq3hFgTV1wLBJGUmb8fyTMPVwCUhsVSMMCaIozfr3XUPBneS2pWyjSVqaYM3B5jG/yqW/4AGKTQjhQ==; DOMAIN=best.aliexpress.ru");

	web_add_cookie("xman_us_f=x_locale=ru_RU&x_l=0&x_c_chg=1&x_as_i=%7B%22aeuCID%22%3A%225276b999662b4a96b8ef1fa4e909f5b4-1582728911258-09340-_NTwOI%22%2C%22af%22%3A%222262685722%22%2C%22channel%22%3A%22AFFILIATE%22%2C%22cookieCacheEffectTime%22%3A1582729211725%2C%22isCookieCache%22%3A%22Y%22%2C%22ms%22%3A%220%22%2C%22pid%22%3A%222262685722%22%2C%22tagtime%22%3A1582728911258%7D&acs_rt=d9a31b3befcb440ea9d349f489be7e74; DOMAIN=best.aliexpress.ru");

	web_url("_dSNvQKk", 
		"URL=https://s.click.aliexpress.com/e/_dSNvQKk", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("analize.js", 
		"URL=https://sonar.semantiqo.com/c83ul/analize.js", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://loadtest.uxcrowd.ru/no-referrer", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body==0neyJzaWQiOiIzMzZlZDliMGI0M2RkMmM1OGFhOTc1MzlhZjQ2OGE3MiIsInlhdGFncyI6IiIsInBhZ2VfZGVzY3JpcHRpb24iOiLQrtC30LDQsdC40LvQuNGC0Lgt0YLQtdGB0YLQuNGA0L7QstCw0L3QuNC1INC90LjQutC+0LPQtNCwINC90LUg0LHRi9C70L4g0L/RgNC+0YnQtSEg0J/QvtC70YPRh9C40YLQtSDQstC40LTQtdC+LCDQvdCwINC60L7RgtC+0YDRi9GFINC70Y7QtNC4INC00LXQu9GP0YLRgdGPINCy0L/QtdGH0LDRgtC70LXQvdC40Y/QvNC4INC+INCy0LDRiNC10Lwg0YHQsNC50YLQtSwg0LzQvtCx0LjQu9GM0L3QvtC8INC/0YDQuNC70L7QttC10L3QuNC4INC40LvQuCDQv9GA0L7RgtC+0YLQuNC/"
		"0LUuIiwicGFnZV9rZXl3b3JkcyI6ItCu0LfQsNCx0LjQu9C40YLQuC3RgtC10YHRgtC40YDQvtCy0LDQvdC40LUiLCJocmVmIjoiaHR0cHMlM0ElMkYlMkZsb2FkdGVzdC51eGNyb3dkLnJ1JTJGIiwicmVmZXJyZXIiOiIiLCJ1c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvODQuMC40MTQ3LjEzNSBTYWZhcmkvNTM3LjM2IiwicmVxdWVzdF9pZCI6IjRmOWRiNzI5NjRjMzRiNmE4MTg2NzlkYjczOWE3MmY3I", 
		LAST);

	web_url("fkbc3no8", 
		"URL=https://widget.intercom.io/widget/fkbc3no8", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_custom_request("ping", 
		"URL=https://api-iam.intercom.io/messenger/web/ping", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"Body=app_id=fkbc3no8&v=3&g=38ffb122c4225b7b8d93b9993d818e7b5fa8934b&s=b3de6538-0048-4ed2-bdb9-0d211093e2d1&i=&r=&platform=web&Idempotency-Key=a63e8ac912f9690c&user_data=%7B%22anonymous_id%22%3A%228b9b67e7-80d6-47fb-b707-eb3407cbad65%22%7D&internal=%7B%7D&page_title="
		"%D0%AE%D0%B7%D0%B0%D0%B1%D0%B8%D0%BB%D0%B8%D1%82%D0%B8-%D1%82%D0%B5%D1%81%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20%D0%BD%D0%B0%20%D1%80%D0%B5%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D1%85%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F%D1%85%20%E2%80%93%20UXCrowd&user_active_company_id=undefined&source=apiBoot&sampling=false&h=false&referer=https%3A%2F%2Floadtest.uxcrowd.ru%2F", 
		LAST);

	web_websocket_connect("ID=0", 
		"URI=wss://nexus-websocket-a.intercom.io/pubsub/5-FXgQ8HkpA4aTq0zvJnatq4u75LkTV_JM4xybLj3Ssgv0rlScXyeL2PJtuHvAam4jZA2C3zTebvtFsd5xr4TPMROmMMnOocxdu5Rd?X-Nexus-New-Client=true&X-Nexus-Version=0.5.2&user_role=undefined", 
		"Origin=https://loadtest.uxcrowd.ru", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	/*Connection ID 0 received buffer WebSocketReceive1*/

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://loadtest.uxcrowd.ru/\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Subscribe\",\"nx.Topics\":[\"*\"]}", 
		"IsBinary=0", 
		LAST);

	web_url("modal-login.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_home/modal-login.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/img/flags.png", "Referer=https://loadtest.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	lr_think_time(10);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:1757175135&cup2hreq=ae0995e4d1d791465808f379b2dd1a1ee9a1636a6e59fde24d5f4b0f24977523", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CAFB\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{53ad90d4-af4e-4647-8beb-643d5fbb69ab}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"CAFB\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50+]\",\"cohortname\":\"Chrome [M50+]\",\"enabled\""
		":true,\"packages\":{\"package\":[{\"fp\":\"1.230b49a9ca5eafd03f52fd0986b8082169f72b1551a82b52150b26880f17a866\"}]},\"ping\":{\"ping_freshness\":\"{f275d8c5-11e0-45b8-bf2d-50107090f53d}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"32.0.0.414\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CAFB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{65236044-4ec7-42b1-b3fb-ad5fc430b161}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"4.10.1679.0\"},{\"appid\":\""
		"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"CAFB\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3c2b158b832ae33ad001f38944608ef84a0d286eeb60bbfb7480fd98f6d171c8\"}]},\"ping\":{\"ping_freshness\":\"{27889402-1132-4344-8d2f-782df0b89a91}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CAFB\",\"cohort\":\"1:bm1:w43@0.01,w6l@0.01\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\""
		"packages\":{\"package\":[{\"fp\":\"1.be38024ec5be84ceb352d02d5d4b6220e9d6b311d4ad2fdf39a0d0cf3741664a\"}]},\"ping\":{\"ping_freshness\":\"{f0fc22a5-81b2-4b5a-a420-fd7996acc628}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"9.15.1\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CAFB\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.0439fc96e4ad1f64b901872ac8ddbdbca709db72613b79a98ea12ec847c4a6d2\"}]},\""
		"ping\":{\"ping_freshness\":\"{e951a4ed-8100-490c-99d9-a01c5b379876}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"6065\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CAFB\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3d885f0577e4fd9e5b9251ba18576da6b49e80870ceaafcaa996e3b1dc762c01\"}]},\"ping\":{\"ping_freshness\":\"{355c80f5-47cf-4b5f-a117-ee87a75423a4}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"1.0.0.4\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand"
		"\":\"CAFB\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5cb8df53fe2b86bf838ea2c9ffc3d5ef8460f679a779ac8aa924b5afffd052cb\"}]},\"ping\":{\"ping_freshness\":\"{87a0d95b-7010-44e4-9890-04af54611722}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"42\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CAFB\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\""
		"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{19d8f72d-5cfe-4ace-8ead-5cfe97b26614}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"CAFB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{d3052652-ac65-4f7a-94b8-8175589a81c8}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"CAFB\",\""
		"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.e3b25f229668cbbca53847ad06e81a4e37875dd118f5a75379be4272513a4f1f\"}]},\"ping\":{\"ping_freshness\":\"{ef98c116-c110-48b3-869c-1e01d35ab592}\",\"rd\":4979},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"84.240.200\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"CAFB\",\"cohort\":\"1:p93:\",\"cohorthint\":\"stable32\",\"cohortname\":\"stable32\",\""
		"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a4811ca3f1d231f2cbb8e5ffbacf475f3364e0a4be162e8758578c76a31ce58f\"}]},\"ping\":{\"ping_freshness\":\"{95f73bac-9359-4817-896e-65f34bee38e5}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"2018.7.19.1\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"CAFB\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{e9c305e9-90ff-499e-a0cc-7af3b2f15ecd}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"2018.9.6.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"CAFB\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.074b31edd3411baffb541eefba417242191c3698c005ed1741991b1ab0b02aff\"}]},\"ping\":{\"ping_freshness\":\""
		"{7df7c546-78f3-40bf-ae4a-e2e69482f26d}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"1999\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"CAFB\",\"cohort\":\"1:ut9:wbf@0.01\",\"cohorthint\":\"M80ToM89\",\"cohortname\":\"M80ToM89\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3fce6f4ac4915ccb2166aa3863f88843abe7bec5e48a4736b8873963f6899cd3\"}]},\"ping\":{\"ping_freshness\":\"{54433838-bf98-4939-aa99-9b85d5956311}\",\"rd\":4979},\"updatecheck\":{},\"version\":\""
		"2020.8.10.1142\"},{\"appid\":\"bklopemakmnopmghhmccadeonafabnal\",\"brand\":\"CAFB\",\"cohort\":\"1:swl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6dce22b9a11fa1e62b22559c4a157ce745e7fc63c6c6941a82cf11e8ecf65b0e\"}]},\"ping\":{\"ping_freshness\":\"{098a7231-4eca-4fff-8dea-fe9f7726896d}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"dfcoifdifjfolmglbbogapfcihdgckga\",\"brand\":\"CAFB\",\"cohort\":\"1:v9l:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a842f56eaefb4e5b4e4b34fe001649e553ae413c84f62adda2f3ddf87a99496b\"}]},\"ping\":{\"ping_freshness\":\"{58f61a10-5495-4db5-b39c-a5fde0169f2d}\",\"rd\":4979},\"updatecheck\":{},\"version\":\"1\"}],\"arch\":\"x86\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"physmemory\":2},\"lang\":\"ru\",\"nacl_arch\":\"x86-32\",\"os\":{\"arch\":\"x86\",\"platform\":\"Windows\",\"sp\":\"Service Pack 1\",\""
		"version\":\"6.1.7601.0\"},\"prodversion\":\"84.0.4147.135\",\"protocol\":\"3.1\",\"requestid\":\"{5de78df8-832b-4ec7-8558-f5bc908a1850}\",\"sessionid\":\"{2869243a-02b3-4e18-a797-6e6fddea4057}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.35.452\"},\"updaterversion\":\"84.0.4147.135\"}}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINODQuMC40MTQ3LjEzNRonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgG-5LPRSIEIAEgAigDGicICRABGhkKDQgJEAYYASIDMDAxMAYQAxoCGAbWgwduIgQgASACKAYaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARCr_AcaAhgGDddV0iIEIAEgAigBGikIBRABGhsKDQgFEAYYASIDMDAxMAEQtZAJGgIYBvTdxdgiBCABIAIoARooCAEQCBoaCg0IARAIGAEiAzAwMTAEEIYbGgIYBt1VfFciBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTABEB0aAhgGXlDKPiIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ0AkaAhgGmf3W3CIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQuHkaAhgG3Cf-sSIEIAEgAigBGikIARABGhsKDQ"
		"gBEAYYASIDMDAxMAEQy-MHGgIYBv-R4E4iBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAYaAhgGUkAbSCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQq-oHGgIYBjYLQvQiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEJIFGgIYBlabdkoiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEKaQBBoCGAa_kaEwIgQgASACKAEaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARDTORoCGAaJ_Q2IIgQgASACKAEiAggB&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1597875227953\",\"eventData\":{\"sendTime\":1597875227953,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-FXgQ8HkpA4aTq0zvJnatq4u75LkTV_JM4xybLj3Ssgv0rlScXyeL2PJtuHvAam4jZA2C3zTebvtFsd5xr4TPMROmMMnOocxdu5Rd\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive2*/

	lr_think_time(12);

	web_custom_request("analize.js_2", 
		"URL=https://sonar.semantiqo.com/c83ul/analize.js", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://loadtest.uxcrowd.ru/no-referrer", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body==0neyJsIjoiYmxhYmxhQGJsYS5ydSIsInNpZCI6IjMzNmVkOWIwYjQzZGQyYzU4YWE5NzUzOWFmNDY4YTcyIiwicmVxdWVzdF9pZCI6IjY5ODFhZTMyYTJlNTRjMmViNGVmZDExM2M0MDVjODYyI", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive3*/

	lr_think_time(9);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://loadtest.uxcrowd.ru/\"}}", 
		"IsBinary=0", 
		LAST);

	lr_think_time(11);

	web_custom_request("analize.js_3", 
		"URL=https://sonar.semantiqo.com/c83ul/analize.js", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://loadtest.uxcrowd.ru/no-referrer", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body==0neyJlIjoiKzcgOTY4IDcwNi04MC0zNiIsInNpZCI6IjMzNmVkOWIwYjQzZGQyYzU4YWE5NzUzOWFmNDY4YTcyIiwicmVxdWVzdF9pZCI6IjM4ODhkYTcwY2QyMDQxMTI5Mzc4OTVmY2IxMGI3ODAzI", 
		LAST);

	lr_think_time(28);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1597875287919\",\"eventData\":{\"sendTime\":1597875287919,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-FXgQ8HkpA4aTq0zvJnatq4u75LkTV_JM4xybLj3Ssgv0rlScXyeL2PJtuHvAam4jZA2C3zTebvtFsd5xr4TPMROmMMnOocxdu5Rd\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive4*/

	web_custom_request("register", 
		"URL=https://loadtest.uxcrowd.ru/api/register", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"name\":\"someName\",\"position\":\"any\",\"company\":\"any.company\",\"email\":\"blabla@bla.ru\",\"telNumber\":\"+7 968 706-80-36\",\"site\":\"http://google.com/bla\",\"role\":\"ROLE_CUSTOMER\",\"tariffType\":\"PROJECT\"}", 
		LAST);

	web_url("modal_window.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_home/modal_window.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		LAST);

	web_url("header.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_landing_new/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footerWhite.html", 
		"URL=https://loadtest.uxcrowd.ru/tmpl/tmpl_landing_new/footerWhite.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/images/burger-gray-mobile.svg", "Referer=https://loadtest.uxcrowd.ru/success_client", ENDITEM, 
		"Url=/assets/images/uxcrowd-logo-green-mobile.svg", "Referer=https://loadtest.uxcrowd.ru/success_client", ENDITEM, 
		"Url=/assets/images/avatar-gray-mobile.svg", "Referer=https://loadtest.uxcrowd.ru/success_client", ENDITEM, 
		"Url=/assets/images/ux-logo-new-green.svg", "Referer=https://loadtest.uxcrowd.ru/success_client", ENDITEM, 
		LAST);

	web_submit_data("ping_2", 
		"Action=https://api-iam.intercom.io/messenger/web/ping", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app_id", "Value=fkbc3no8", ENDITEM, 
		"Name=v", "Value=3", ENDITEM, 
		"Name=g", "Value=38ffb122c4225b7b8d93b9993d818e7b5fa8934b", ENDITEM, 
		"Name=s", "Value=b3de6538-0048-4ed2-bdb9-0d211093e2d1", ENDITEM, 
		"Name=i", "Value=", ENDITEM, 
		"Name=r", "Value=", ENDITEM, 
		"Name=platform", "Value=web", ENDITEM, 
		"Name=Idempotency-Key", "Value=054241638e9a0d32", ENDITEM, 
		"Name=user_data", "Value={\"anonymous_id\":\"8b9b67e7-80d6-47fb-b707-eb3407cbad65\"}", ENDITEM, 
		"Name=internal", "Value={}", ENDITEM, 
		"Name=page_title", "Value=Успеx", ENDITEM, 
		"Name=user_active_company_id", "Value=-1", ENDITEM, 
		"Name=source", "Value=apiUpdate", ENDITEM, 
		"Name=sampling", "Value=false", ENDITEM, 
		"Name=h", "Value=false", ENDITEM, 
		"Name=referer", "Value=https://loadtest.uxcrowd.ru/success_client", ENDITEM, 
		LAST);

	return 0;
}