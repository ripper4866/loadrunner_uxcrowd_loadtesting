Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");


	web_url("loadtest.uxcrowd.ru", 
		"URL=https://loadtest.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t43.inf", 
		"Mode=HTML",
		LAST);
	
	web_reg_save_param_regexp (
    "ParamName=XSRF-TOKEN",
    "RegExp=XSRF-TOKEN=(.+);",
     LAST);
	
    web_url("ru.json", 
    "URL=https://loadtest.uxcrowd.ru/assets/lang/ru.json", 
    "TargetFrame=", 
    "Resource=0", 
    "RecContentType=application/json", 
    "Referer=https://loadtest.uxcrowd.ru/", 
    "Snapshot=t2.inf", 
    "Mode=HTML", 
    EXTRARES, 
    "Url=/api/account", ENDITEM, 
    LAST);
	
	web_add_auto_header("X-XSRF-TOKEN", 
		"{XSRF-TOKEN}");
	

	web_url("loadtest.uxcrowd.ru_2", 
		"URL=https://loadtest.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);
	
	web_custom_request("register", 
		"URL=https://loadtest.uxcrowd.ru/api/register", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://loadtest.uxcrowd.ru/", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"name\":\"someName\",\"position\":\"any\",\"company\":\"any.company\",\"email\":\"differentmail{NewRandParam1}{NewRandParam1}@enayu.com\",\"telNumber\":\"+7 968 706-80-38\",\"site\":\"http://google.com/blabla\",\"role\":\"ROLE_CUSTOMER\",\"tariffType\":\"PROJECT\"}", 
		LAST);

	return 0;
}